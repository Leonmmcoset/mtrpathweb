from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import *
from .mtrpath import run
# Create your views here.
def index(request):
    if request.method == 'POST':
        # 获取输入框的值并转化为 Python 变量
        input1_value = request.POST.get('input1')
        input2_value = request.POST.get('input2')
        update_value = request.POST.get('input')
        server_value = request.POST.get('server')
        if update_value == '是':
            update_value = True
        elif update_value == '否':
            update_value = False
        else:
            return redirect('../application/static/error2.jpg')
        # 这里可以对获取到的变量进行进一步处理
        print(f"输入框 1 的值: {input1_value}")
        print(f"输入框 2 的值: {input2_value}")
        print(f'是否更新: {update_value}')
        print(f'服务器: {server_value}')
        if server_value == '1':
            server_value = 'http://leonmmcoset.jjmm.ink:25565'
        elif server_value == '2':
            server_value = 'http://leonmmcoset.jjmm.ink:8810'
        elif server_value == '3':
            server_value = 'http://leonmmcoset.jjmm.ink:8999'
        try:
            run(input1_value, input2_value, update_value, server_value)
        except:
            return redirect('../application/static/error.jpg')

        # 重定向到成功页面
        return redirect('formtest/')

    return render(request, 'index.html')

def formtest(request):
    return redirect('../application/static/temp.jpg')